# Unity_HoleVsColors
Hyper casual game (Hole vs Colors)  
Tutorial: 

[![Tutorial](https://img.youtube.com/vi/aCiz0_w30yo/0.jpg)](https://www.youtube.com/watch?v=aCiz0_w30yo)

## How to fix hole issues :
<img src="https://raw.githubusercontent.com/herbou/Unity_HoleVsColors/master/How%20to%20fix%20hole%20issues.PNG" width="auto" />

<br><br>
## ❤️ Donate

<a href="https://paypal.me/hamzaherbou" title="https://paypal.me/hamzaherbou" target="_blank"><img align="left" height="50" src="https://www.mediafire.com/convkey/72dc/iz78ys7vtfsl957zg.jpg" alt="Paypal"></a>

<a href="https://www.buymeacoffee.com/hamzaherbou" title="https://www.buymeacoffee.com/hamzaherbou" target="_blank"><img align="left" height="50" src="https://www.mediafire.com/convkey/66bc/dg3xdk96km1pt7gzg.jpg" alt="BuyMeACoffee"></a>

<a href="https://patreon.com/herbou" title="https://patreon.com/herbou" target="_blank"><img align="left" height="50" src="https://www.mediafire.com/convkey/57b1/0h171bqmdesoljczg.jpg" alt="Patreon"></a>
