﻿public class Game
{
	public static bool isGameover = false;
	public static bool isMoving = false;
}
